#ifndef TREE_MAP_CPP
#define TREE_MAP_CPP

#include "TreeMap.hpp"
#include "TreeSet.cpp"
template <typename TKey, typename TValue>
TreeMap<TKey, TValue>::TreeMap() {
    auto _comparator = [](std::pair<TKey, TValue> left, std::pair<TKey, TValue> right) {
        if (left.first < right.first)
        {
            return -1;
        }
        else if (left.first > right.first)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    };
    _tree = TreeSet<std::pair<TKey, TValue>>(_comparator);
}

template <typename TKey, typename TValue>
TreeMap<TKey, TValue>::TreeMap(const std::vector<std::pair<TKey, TValue>> &items) : TreeMap(){
    for (const auto &pair : items) {
        _tree.add(pair);
    }
}
    /// @brief Returns the number of elements in the map.
    /// @return The number of elements in the map.
template <typename TKey, typename TValue>
size_t TreeMap<TKey, TValue>::size() const{
        return _tree.size();
    }

    /// @brief insert a key-value pair into the map
    /// @param key unique key for searching in map
    /// @param value the mapped value of the key
template <typename TKey, typename TValue>
void TreeMap<TKey, TValue>::insert(TKey key, TValue value){
    _tree.add(std::make_pair(key, value));
}

    /// @brief get the value of a key
    /// @param key unique key for searching in map
    /// @return the mapped value
template <typename TKey, typename TValue>
std::optional<TValue> TreeMap<TKey, TValue>::get(TKey key) const{
    auto pair = std::pair(key, TValue{});
    
    for (const auto& pair : _tree.to_vector()) {
        if (pair.first == key) {
            return pair.second;
        }
    }
    return std::nullopt;
}

    /// @brief check if a key is in the map
    /// @param key unique key to search for
    /// @return true if key is in the map, otherwise false
template <typename TKey, typename TValue>
bool TreeMap<TKey, TValue>::contains(TKey key) const{
    for (const auto &pair : _tree.to_vector()) {
        if (pair.first == key) {
            return true;
        }
    }
    return false;
}

    /// @brief traverse the map in order and return the values as a vector
    /// @return a sorted vector containing all kv-pair in the map
template <typename TKey, typename TValue>
std::vector<std::pair<TKey, TValue>> TreeMap<TKey, TValue>::to_vector() const{
    return _tree.to_vector();
}

    /// @brief check if the map is empty
    /// @return true if the map is empty, otherwise false
template <typename TKey, typename TValue>
bool TreeMap<TKey, TValue>::is_empty() const{
    return _tree.is_empty();
}

template <typename TKey, typename TValue>
TreeMap<TKey, TValue>::~TreeMap(){
    clear();
};

    /// @brief remove every element in the set
template <typename TKey, typename TValue>
void TreeMap<TKey, TValue>::clear(){
    _tree.clear();
};

#endif
