#ifndef TREE_SET_CPP
#define TREE_SET_CPP

#include "TreeSet.hpp"

template <typename T>
TreeSet<T>::TreeSet() : _root(nullptr), _size(0) {
    _comparator = [](T left, T right) {
        if (left < right)
        {
            return -1;
        }
        else if (left > right)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    };
}

 // Red-Black Tree functions
    // if not doing Red-Black tree, these functions can be empty

    /// @brief fix any violation of red-black tree properties
    /// @param z the new node inserted
    /// @note textbook 13.3 P.339
template <typename T>
void TreeSet<T>::fix_violation(BinaryTreeNode<T> *z){
    while (z->_parent->_parent != nullptr && z->_parent != nullptr && z->_parent->_color == Red) {
        if (z->_parent == z->_parent->_parent->_left) {
            // z's parent is a left child of its grandparent
            BinaryTreeNode<T> *y = z->_parent->_parent->_right; // z's uncle
            if (y != nullptr && y->_color == Red) {
                // Case 1: z's uncle is red
                z->_parent->_color = Black;
                y->_color = Black;
                z->_parent->_parent->_color = Red;
                z = z->_parent->_parent;
            } 
            else {
                if (z == z->_parent->_right) {
                    // Case 2: z's uncle is black and z is a right child
                    z = z->_parent;
                    rotate_left(z);
                }
                // Case 3: z's uncle is black and z is a left child
                z->_parent->_color = Black;
                z->_parent->_parent->_color = Red;
                rotate_right(z->_parent->_parent);
            }
        } 
        else {
            BinaryTreeNode<T> *y = z->_parent->_parent->_left; // z's uncle
            if (y != nullptr && y->_color == Red) {
                // Case 1: z's uncle is red
                z->_parent->_color = Black;
                y->_color = Black;
                z->_parent->_parent->_color = Red;
                z = z->_parent->_parent;
            } 
            else {
                if (z == z->_parent->_left) {
                    // Case 2: z's uncle is black and z is a right child
                    z = z->_parent;
                    rotate_right(z);
                }
                // Case 3: z's uncle is black and z is a left child
                z->_parent->_color = Black;
                z->_parent->_parent->_color = Red;
                rotate_left(z->_parent->_parent);
            // z's parent is a right child of its grandparent
            }
        }
    }

    // Ensure the root is black
    if (_root != nullptr) {
        _root->_color = Black;
    }
}


    /// @brief left rotation
    /// @param x the node to rotate on
    /// @note textbook 13.2 P.336
template <typename T>
void TreeSet<T>::rotate_left(BinaryTreeNode<T> *x){
    BinaryTreeNode<T> *y = x->_right;
    if (y != nullptr){
        x->_right = y->_left;
        if (y->_left != nullptr) {
            y->_left->_parent = x;
        }
        y->_parent = x->_parent;

        if (x->_parent ==  nullptr) {
            _root = y;
        }
        else if (x == x->_parent->_left) {
            x->_parent->_left = y;
        }
        else{
            x->_parent->_right = y;
        }

        y->_left = x;
        x->_parent = y;
    }
    //return;
}

    /// @brief Right rotation
    /// @param y the node to rotate on
    /// @note textbook P.336 exercise 13.2-1
template <typename T>
void TreeSet<T>::rotate_right(BinaryTreeNode<T> *x){
    BinaryTreeNode<T> *y = x->_left;
    if (y != nullptr){
        x->_left = y->_right;

        if (y->_right != nullptr){
            y->_right->_parent = x;
        }
        y->_parent = x->_parent;

        if (x->_parent ==  nullptr){
            _root = y;
        }
        else if (x == x->_parent->_right){
            x->_parent->_right = y;
        }
        else{
            x->_parent->_left = y;
        }

        y->_right = x;
        x->_parent = y;
    }
    //return;
}

template <typename T>
TreeSet<T>::TreeSet(const std::vector<T> &items){
    _size = 0;
    _root = nullptr;
    _comparator = [](T left, T right) {
        if (left < right)
        {
            return -1;
        }
        else if (left > right)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    };
    for (const T &item:items){
        add(item);
    }
}
template <typename T>
TreeSet<T>::TreeSet(std::function<int(T, T)> comparator){
    _size = 0;
    _root = nullptr;
    _comparator = comparator;
}
template <typename T>  
TreeSet<T>::TreeSet(const std::vector<T> &items, std::function<int(T, T)> comparator){
    _size = 0;
    _root = nullptr;
    _comparator = comparator;
    for (const T &item:items){
        add(item);
    }
}

    /// @brief Returns the number of elements in the tree.
    /// @return The number of elements in the tree.
template <typename T>
size_t TreeSet<T>::size() const{
    return _size;
}

    /// @brief adds a value to the set.
    /// If there is an element whose value equals (checked by comparator) `value`,
    /// the existing value will be replaced by `value`.
    /// @param value put this value into the set
template <typename T>
void TreeSet<T>::add(T value){
    BinaryTreeNode<T> *TreeNode = new BinaryTreeNode<T>(value);
    TreeNode->_color = Red;
    if (_root == nullptr){
        _root = TreeNode;
        _size++;
        _root->_color = Black;
    }
    else{
        BinaryTreeNode<T> *temp = _root;
        BinaryTreeNode<T> *parent = nullptr;

        while (temp != nullptr){
            parent = temp;
            if (_comparator(temp->value, value) < 0){
                if(temp->_right == nullptr){
                    temp->_right = TreeNode;
                    TreeNode->_parent = temp;
                    _size++;
                    return;
                }
                else{
                    temp = temp->_right;
                }
            }
            else if (_comparator(temp->value, value) > 0){
                if (temp->_left == nullptr){
                    temp->_left = TreeNode;
                    TreeNode->_parent = temp;
                    _size++;
                    return;
                }
                else{
                    temp = temp->_left;
                }
            }
            else{
                BinaryTreeNode<T>* NewNode = new BinaryTreeNode<T>(value);
                NewNode->_color = Black;
                NewNode->_left = temp->_left;
                NewNode->_right = temp->_right;

                if (temp == _root){
                    _root = NewNode;
                } 
                else if (parent->_left == temp){
                    parent->_left = NewNode;
                } 
                else {
                    parent->_right = NewNode;
                }

                if (temp != nullptr) {
                delete temp;
                }
            }
        }
    }
//                if (_comparator(temp->value, value) == 0){
//                    temp->value = value;
//                    delete TreeNode;
//                    return;
                    //return;
//                }
        
    fix_violation(TreeNode);
}

    /// @brief check if a element is in the set
    /// @param value the element
    /// @return true if value is in the set, otherwise false
template <typename T>
bool TreeSet<T>::contains(T value) const{
    BinaryTreeNode<T> *temp = _root;
    while(temp != nullptr){
        if (_comparator(temp->value, value) < 0){
            temp = temp->_right;
        }
        if (_comparator(temp->value, value) > 0){
            temp = temp->_left;
        }
        else{
            if (_comparator(temp->value, value) == 0){
                return true;
            }
        }
    }
    return false;
}

    /// @brief check if the set is empty
    /// @return true if the set is empty, otherwise false
template <typename T>
bool TreeSet<T>::is_empty() const{
    if (_root == nullptr){
        return true;
    }
    else{
        return false;
    }
}

    /// @brief search for the smallest value in the set
    /// @return the minimum value in the set
template <typename T>
std::optional<T> TreeSet<T>::min() const{       
    if (_root == nullptr){
        return std::nullopt;
    }
    BinaryTreeNode<T> *temp = _root;
    while (temp->_left != nullptr){
        temp = temp->_left;
    }                                               //on the left of the tree are the minimum values/smaller values
    return temp->value;
}

    /// @brief search for the largest value in the set
    /// @return the maximum value in the set
template <typename T>
std::optional<T> TreeSet<T>::max() const{
    if (_root == nullptr){
        return std::nullopt;
    }
    BinaryTreeNode<T> *temp = _root;
    while (temp->_right != nullptr){
        temp = temp->_right;
    }
    return temp->value;
}

    /// @brief traverse the set in order and return the values as a vector
    /// @return a sorted vector containing all values in the set
template <typename T>
std::vector<T> TreeSet<T>::to_vector() const{
    std::vector<T> sort;
    std::function<void(BinaryTreeNode<T> *)> traverse = [&] (BinaryTreeNode<T> *TreeNode){
        if(TreeNode != nullptr){
            traverse(TreeNode->_left);
            sort.push_back(TreeNode->value);
            traverse(TreeNode->_right);
        }
        else{
            return;
        }
    };
    traverse(_root);
    return sort;
}

//     std::vector<T> sort;
    
//     auto traverse = [&](const BinaryTreeNode<T>* TreeNode) -> void {
//         if (TreeNode != nullptr) {
//             traverse(TreeNode->left);
//             sort.push_back(TreeNode->value);
//             traverse(TreeNode->right);
//         }
//     };
    
//     traverse(_root);
    
//     return sort;
// }

    /// @brief finds a value and return it
    /// @param value 
    /// @return value if found, otherwise std::nullopt
template <typename T>
std::optional<T> TreeSet<T>::get(T value) const{
    BinaryTreeNode<T> *temp = _root;
    while(temp != nullptr){
        if (_comparator(temp->value, value) < 0){
            temp = temp->_right;
        }
        else if (_comparator(temp->value, value) > 0){
            temp = temp->_left;
        }
        else{
            if (_comparator(temp->value, value) == 0){
                return temp->value;
            }
        }
    }
    return std::nullopt;
}

    /// @brief set uniom      //create a new TreeSet and return the tree set
    /// @param other another set to be unioned
    /// @return the result of the union
template <typename T>
TreeSet<T> TreeSet<T>::operator+(const TreeSet<T> &other){
     std::vector<int> v1 = to_vector();
     std::vector<int> v2 = other.to_vector();

     TreeSet<T> unionSet;

     // Add elements from v1 to the unionSet
     for (const T &value:v1) {
        unionSet.add(value);
    }

    // Add elements from v2 to the unionSet
    for (const T &value:v2) {
        unionSet.add(value);
    }

    return unionSet;
}
// }
//     std::vector<T> v1 = to_vector();

//     for(const T &value : other.to_vector()){
//         v1.push_back(value);
//     }
//     TreeSet<T> unionSet(v1);
//     return unionSet;
// }


    /// @brief in-place set union       //add new elements to the current set
    /// @param other another set to be unioned
    /// @return a reference to this set
template <typename T>
TreeSet<T> &TreeSet<T>::operator+=(const TreeSet<T> &other){
    std::vector<T> v2 = other.to_vector();

    // Add elements from v2 to the current set using the 'add' method
    for (const T &value : v2) {
        add(value);
    }
    return *this;
}
//     for (const T &value : other.to_vector()) {
//         add(value);
//     }
// }

    /// @brief set intersection         //create a new set with elements from current and other 
    /// @param other another set
    /// @return the result of the intersection
template <typename T>
TreeSet<T> TreeSet<T>::operator&(const TreeSet<T> &other){
    std::vector<T> v1 = to_vector();
    std::vector<T> v2;

    for (const T &value : other.to_vector()) {
        for(const T &value1 : v1){
            if (value == value1){
                v2.push_back(value);
            }
        }
    }
    TreeSet<T> intersectionSet(v2);
    return intersectionSet;
}

    /// @brief set equal                //check if every element is the same in the current set and the other set
    /// @param other another set
    /// @return true if the two sets contails same elements, otherwise false
template <typename T>
bool TreeSet<T>::operator==(const TreeSet<T> &other) const{
    if (size() != other.size()) {
        return false;
    }

    for (const T &value : to_vector()) {
        if (!other.contains(value)) {
            return false;
        }
    }

    return true;
}

    /// @brief set not equal
    /// @param other another set
    /// @return true if the two sets contails different elements, otherwise false
template <typename T>
bool TreeSet<T>::operator!=(const TreeSet<T> &other) const{
    if (_size != other._size) {
        return true;  // Different sizes mean they can't be equal
    }

    // Iterate through the elements in this TreeSet and check if they exist in the other TreeSet
    for (const T &value : to_vector()) {
        if (!other.contains(value)) {
            return true;  // If an element is not in the other set, they are not equal
        }
    }

    return false;  // All elements match, the sets are equal
}

template <typename T>
TreeSet<T>::~TreeSet(){
    clear();
};

    /// @brief remove every element in the set
template <typename T>
void TreeSet<T>::clear(){

    std::function<void(BinaryTreeNode<T> *)> remove = [&] (BinaryTreeNode<T> *TreeNode){
        if(TreeNode != nullptr){
            remove(TreeNode->_left);
            remove(TreeNode->_right);
            delete TreeNode;
        }
    };
    remove(_root);
    _size = 0;
    _root = nullptr;
    return;
}

#endif
